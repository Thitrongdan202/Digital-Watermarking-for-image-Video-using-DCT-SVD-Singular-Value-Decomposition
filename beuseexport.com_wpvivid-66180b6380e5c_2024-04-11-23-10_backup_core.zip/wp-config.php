<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'nhbeuhvp_wp_l1ruw' );

/** Database username */
define( 'DB_USER', 'nhbeuhvp_wp_3enis' );

/** Database password */
define( 'DB_PASSWORD', 'Tung2013@' );

/** Database hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '+-yw(;3(bNDW@#3mr(s@L8@]|74Hj8Uk8)/Y6M7yf%&QwNlNIsN;21CmVIwQ50-3');
define('SECURE_AUTH_KEY', '*|/i8+6ajqde7aL1*4I@7O1q98%5V45UoDbOI80:9770/4_%HFGS78wahRxoQkQ/');
define('LOGGED_IN_KEY', 'zT3jqIA31~5W-9_|NYMq4oYAKY1[BV95gA4m*cQUN~+S|6O!F6oH2612&:7e62l5');
define('NONCE_KEY', 'F]&9Q0(IA9q0Ay0aV113Av5%Y]&elubi7hNKT2b#bnxU97eDlE;!~VQ/rNME~m1T');
define('AUTH_SALT', '+3D3B~#[&~n05ub-[[3&+6(#c%243gO32:8pdTMbrJ0kfJ2(/Nsu:6tY[t8x0%q!');
define('SECURE_AUTH_SALT', '!d6*SB2um8:PzJ9S41br%OL#VK7G~Vr7)zqOqEDmjcn)29jN886bYWe8M)8y+f9(');
define('LOGGED_IN_SALT', ':QM#~lN3Cq5aUyF80EGf)a7ak8MRYzAZ_R69TM~FsdU]xsq2:FEl+#CCo7*%G;h:');
define('NONCE_SALT', 'b*qdT7*]Vo94Z@(7M_2DT5&%w)e0]Nu//4D~SZ;Zy&8:mSR6M-h*K~ov~(58dw/h');


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'qD2Xrfv_';


/* Add any custom values between this line and the "stop editing" line. */

define('WP_ALLOW_MULTISITE', true);
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
