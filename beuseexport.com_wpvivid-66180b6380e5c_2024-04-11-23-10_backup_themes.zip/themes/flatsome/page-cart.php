<?php
/*
Template name: WooCommerce - Cart
*/

wc_get_template_part('checkout/layouts/checkout', get_theme_mod('cart_layout'));

?>
